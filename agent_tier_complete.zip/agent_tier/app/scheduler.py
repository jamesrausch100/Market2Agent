"""
Market2Agent - Scheduled Jobs
Weekly audits and email alerts for subscribed users.
"""
import asyncio
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
import structlog

from app.config import settings
from app.db import get_neo4j_driver
from app.worker import enqueue_audit

logger = structlog.get_logger()


# ===========================================
# Email Sending
# ===========================================

def send_email(to_email: str, subject: str, html_body: str):
    """Send an email via SMTP."""
    if not settings.SMTP_USER or not settings.SMTP_PASSWORD:
        logger.warning("email_skipped", reason="SMTP not configured")
        return False
    
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = f"Market2Agent <{settings.SMTP_USER}>"
        msg['To'] = to_email
        
        html_part = MIMEText(html_body, 'html')
        msg.attach(html_part)
        
        with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT) as server:
            server.starttls()
            server.login(settings.SMTP_USER, settings.SMTP_PASSWORD)
            server.sendmail(settings.SMTP_USER, to_email, msg.as_string())
        
        logger.info("email_sent", to=to_email, subject=subject)
        return True
        
    except Exception as e:
        logger.error("email_failed", to=to_email, error=str(e))
        return False


def send_score_alert(user_email: str, user_name: str, domain: str, old_score: float, new_score: float, grade: str):
    """Send score change alert email."""
    
    change = new_score - old_score
    direction = "improved" if change > 0 else "dropped"
    change_abs = abs(change)
    
    subject = f"🔔 {domain} GEO score {direction} by {change_abs:.0f} points"
    
    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #334155; }}
            .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
            .header {{ background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%); color: white; padding: 30px; border-radius: 12px 12px 0 0; }}
            .content {{ background: #f8fafc; padding: 30px; border-radius: 0 0 12px 12px; }}
            .score-box {{ background: white; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0; }}
            .score {{ font-size: 48px; font-weight: bold; color: {'#22c55e' if change > 0 else '#ef4444'}; }}
            .grade {{ font-size: 24px; color: #64748b; }}
            .change {{ font-size: 18px; color: {'#22c55e' if change > 0 else '#ef4444'}; margin-top: 10px; }}
            .button {{ display: inline-block; background: #0ea5e9; color: white; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 600; }}
            .footer {{ text-align: center; margin-top: 30px; font-size: 14px; color: #94a3b8; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1 style="margin: 0;">GEO Score Alert</h1>
                <p style="margin: 10px 0 0 0; opacity: 0.9;">Your weekly audit is complete</p>
            </div>
            <div class="content">
                <p>Hi {user_name},</p>
                <p>Your weekly GEO audit for <strong>{domain}</strong> has completed.</p>
                
                <div class="score-box">
                    <div class="score">{new_score:.0f}</div>
                    <div class="grade">Grade: {grade}</div>
                    <div class="change">{'↑' if change > 0 else '↓'} {change_abs:.0f} points from last week</div>
                </div>
                
                <p>{'Great progress! Keep optimizing.' if change > 0 else 'Your score dropped. Check the dashboard for recommendations.'}</p>
                
                <p style="text-align: center; margin-top: 30px;">
                    <a href="{settings.APP_URL}/dashboard.html" class="button">View Full Report</a>
                </p>
            </div>
            <div class="footer">
                <p>Market2Agent • Denver, CO</p>
                <p><a href="{settings.APP_URL}/settings.html" style="color: #64748b;">Manage email preferences</a></p>
            </div>
        </div>
    </body>
    </html>
    """
    
    return send_email(user_email, subject, html)


def send_welcome_email(user_email: str, user_name: str):
    """Send welcome email to new subscriber."""
    
    subject = "Welcome to Market2Agent Agent Tier! 🚀"
    
    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #334155; }}
            .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
            .header {{ background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%); color: white; padding: 30px; border-radius: 12px 12px 0 0; }}
            .content {{ background: #f8fafc; padding: 30px; border-radius: 0 0 12px 12px; }}
            .feature {{ background: white; padding: 15px; border-radius: 8px; margin: 10px 0; }}
            .button {{ display: inline-block; background: #0ea5e9; color: white; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 600; }}
            .footer {{ text-align: center; margin-top: 30px; font-size: 14px; color: #94a3b8; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1 style="margin: 0;">Welcome to Agent Tier!</h1>
                <p style="margin: 10px 0 0 0; opacity: 0.9;">Your AI visibility journey starts now</p>
            </div>
            <div class="content">
                <p>Hi {user_name},</p>
                <p>Thanks for subscribing to Market2Agent Agent Tier! Here's what you now have access to:</p>
                
                <div class="feature">✅ <strong>Track up to 10 domains</strong></div>
                <div class="feature">✅ <strong>Weekly automated audits</strong></div>
                <div class="feature">✅ <strong>Email alerts when scores change</strong></div>
                <div class="feature">✅ <strong>Full recommendation history</strong></div>
                <div class="feature">✅ <strong>Schema.org templates</strong></div>
                
                <p style="margin-top: 20px;"><strong>Next steps:</strong></p>
                <ol>
                    <li>Add your domains to track</li>
                    <li>Run your first audit</li>
                    <li>Review recommendations and start improving</li>
                </ol>
                
                <p style="text-align: center; margin-top: 30px;">
                    <a href="{settings.APP_URL}/dashboard.html" class="button">Go to Dashboard</a>
                </p>
            </div>
            <div class="footer">
                <p>Questions? Reply to this email or contact support@market2agent.ai</p>
                <p>Market2Agent • Denver, CO</p>
            </div>
        </div>
    </body>
    </html>
    """
    
    return send_email(user_email, subject, html)


# ===========================================
# Weekly Audit Job
# ===========================================

async def run_weekly_audits():
    """
    Run weekly audits for all subscribed users.
    Should be triggered by a cron job every Sunday at midnight.
    """
    logger.info("weekly_audits_started")
    
    driver = get_neo4j_driver()
    
    with driver.session() as session:
        # Get all active subscribers and their domains
        result = session.run("""
            MATCH (u:User {subscription_status: 'active'})-[:OWNS]->(d:Domain)
            RETURN u.id as user_id, u.email as email, u.name as name, 
                   d.name as domain, d.current_score as previous_score
        """)
        
        jobs = []
        for record in result:
            jobs.append({
                "user_id": record["user_id"],
                "email": record["email"],
                "name": record["name"],
                "domain": record["domain"],
                "previous_score": record["previous_score"] or 0
            })
    
    logger.info("weekly_audits_queued", count=len(jobs))
    
    # Enqueue all audits
    for job in jobs:
        import uuid
        audit_id = str(uuid.uuid4())
        
        # Store the job metadata for the alert
        with driver.session() as session:
            session.run("""
                CREATE (j:ScheduledAuditJob {
                    audit_id: $audit_id,
                    user_id: $user_id,
                    email: $email,
                    name: $name,
                    domain: $domain,
                    previous_score: $previous_score,
                    created_at: datetime()
                })
            """, audit_id=audit_id, **job)
        
        await enqueue_audit(audit_id, job["domain"])
    
    logger.info("weekly_audits_complete")
    return len(jobs)


async def process_audit_alerts():
    """
    Check completed audits and send alerts for score changes.
    Should run after weekly audits complete (e.g., Sunday 1am).
    """
    logger.info("processing_audit_alerts")
    
    driver = get_neo4j_driver()
    
    with driver.session() as session:
        # Get completed scheduled audits that haven't been alerted yet
        result = session.run("""
            MATCH (j:ScheduledAuditJob)
            WHERE NOT j.alert_sent
            MATCH (a:Audit {audit_id: j.audit_id})
            WHERE a.status = 'complete'
            RETURN j, a.overall_score as new_score, a.raw_data as raw_data
        """)
        
        alerts_sent = 0
        for record in result:
            job = record["j"]
            new_score = record["new_score"]
            previous_score = job["previous_score"]
            
            # Parse grade from raw_data
            import json
            try:
                data = json.loads(record["raw_data"] or "{}")
                grade = data.get("grade", "?")
            except:
                grade = "?"
            
            # Only alert if score changed by more than 5 points
            if abs(new_score - previous_score) >= 5:
                send_score_alert(
                    user_email=job["email"],
                    user_name=job["name"],
                    domain=job["domain"],
                    old_score=previous_score,
                    new_score=new_score,
                    grade=grade
                )
                alerts_sent += 1
            
            # Mark as alerted
            session.run("""
                MATCH (j:ScheduledAuditJob {audit_id: $audit_id})
                SET j.alert_sent = true, j.alerted_at = datetime()
            """, audit_id=job["audit_id"])
    
    logger.info("audit_alerts_processed", alerts_sent=alerts_sent)
    return alerts_sent


# ===========================================
# CLI Entry Points
# ===========================================

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python -m app.scheduler <command>")
        print("Commands: weekly_audits, process_alerts")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "weekly_audits":
        count = asyncio.run(run_weekly_audits())
        print(f"Queued {count} audits")
    
    elif command == "process_alerts":
        count = asyncio.run(process_audit_alerts())
        print(f"Sent {count} alerts")
    
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)
