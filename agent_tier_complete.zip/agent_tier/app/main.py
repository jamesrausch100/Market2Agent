"""
Market2Agent Audit Engine - Main API
Updated with auth, subscriptions, and dashboard routes.
"""
from fastapi import FastAPI, HTTPException, BackgroundTasks, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, field_validator
from typing import Optional
import re
import uuid
from datetime import datetime

from app.config import settings
from app.db import get_neo4j_driver
from app.crawlers.structured_data import extract_structured_data
from app.crawlers.entity_presence import check_entity_presence
from app.analyzers.scoring import calculate_geo_score
from app.worker import enqueue_audit

# Import routers
from app.auth import router as auth_router
from app.subscriptions import router as subscriptions_router
from app.dashboard import router as dashboard_router

app = FastAPI(
    title="Market2Agent Audit API",
    description="GEO (Generative Engine Optimization) Audit Platform",
    version="1.0.0"
)

# CORS - allow requests from frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://market2agent.ai",
        "https://www.market2agent.ai",
        "https://market2agent.com",
        "https://www.market2agent.com",
        "http://localhost:3000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth_router)
app.include_router(subscriptions_router)
app.include_router(dashboard_router)


# --------------------------------------------------------------
# Request/Response Models
# --------------------------------------------------------------

class AuditRequest(BaseModel):
    domain: str
    
    @field_validator('domain')
    @classmethod
    def validate_domain(cls, v: str) -> str:
        v = v.strip().lower()
        v = re.sub(r'^https?://', '', v)
        v = v.rstrip('/')
        v = re.sub(r'^www\.', '', v)
        
        pattern = r'^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z]{2,})+$'
        if not re.match(pattern, v):
            raise ValueError('Invalid domain format')
        return v


class AuditResponse(BaseModel):
    audit_id: str
    domain: str
    status: str
    message: str


class AuditResult(BaseModel):
    audit_id: str
    domain: str
    status: str
    created_at: datetime
    overall_score: float
    scores: dict
    findings: list
    entities: list
    recommendations: list


# --------------------------------------------------------------
# API Endpoints
# --------------------------------------------------------------

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "audit-engine", "version": "1.0.0"}


@app.post("/v1/audit", response_model=AuditResponse)
async def request_audit(request: AuditRequest, background_tasks: BackgroundTasks):
    """
    Request a new GEO audit for a domain.
    The audit runs asynchronously - poll /v1/audit/{audit_id} for results.
    """
    audit_id = str(uuid.uuid4())
    
    # Enqueue the audit job
    await enqueue_audit(audit_id, request.domain)
    
    return AuditResponse(
        audit_id=audit_id,
        domain=request.domain,
        status="queued",
        message="Audit queued. Poll /v1/audit/{audit_id} for results."
    )


@app.get("/v1/audit/{audit_id}", response_model=AuditResult)
async def get_audit_result(audit_id: str):
    """
    Get the results of a completed audit.
    """
    driver = get_neo4j_driver()
    
    with driver.session() as session:
        result = session.run("""
            MATCH (a:Audit {audit_id: $audit_id})
            OPTIONAL MATCH (d:Domain)-[:HAS_AUDIT]->(a)
            RETURN a, d.name as domain
        """, audit_id=audit_id)
        
        record = result.single()
        
        if not record:
            raise HTTPException(status_code=404, detail="Audit not found")
        
        audit = record["a"]
        
        if audit.get("status") == "processing":
            # Convert neo4j datetime to native
            created_at = audit["created_at"]
            if hasattr(created_at, 'to_native'):
                created_at = created_at.to_native()
            
            return AuditResult(
                audit_id=audit_id,
                domain=record["domain"] or "",
                status="processing",
                created_at=created_at,
                overall_score=0,
                scores={},
                findings=[],
                entities=[],
                recommendations=["Audit in progress..."]
            )
        
        # Parse the stored JSON data
        import json
        raw_data = json.loads(audit.get("raw_data", "{}"))
        
        # Convert neo4j datetime to native
        created_at = audit["created_at"]
        if hasattr(created_at, 'to_native'):
            created_at = created_at.to_native()
        
        return AuditResult(
            audit_id=audit_id,
            domain=record["domain"] or raw_data.get("domain", ""),
            status=audit.get("status", "unknown"),
            created_at=created_at,
            overall_score=audit.get("overall_score", 0),
            scores=raw_data.get("scores", {}),
            findings=raw_data.get("findings", []),
            entities=raw_data.get("entities", []),
            recommendations=raw_data.get("recommendations", [])
        )


@app.get("/v1/domain/{domain}/history")
async def get_domain_history(domain: str, limit: int = 10):
    """
    Get audit history for a domain.
    """
    driver = get_neo4j_driver()
    
    with driver.session() as session:
        result = session.run("""
            MATCH (d:Domain {name: $domain})-[:HAS_AUDIT]->(a:Audit)
            WHERE a.status = 'complete'
            RETURN a.audit_id as audit_id, 
                   a.created_at as created_at,
                   a.overall_score as score
            ORDER BY a.created_at DESC
            LIMIT $limit
        """, domain=domain.lower(), limit=limit)
        
        history = []
        for r in result:
            created_at = r["created_at"]
            if hasattr(created_at, 'to_native'):
                created_at = created_at.to_native().isoformat()
            
            history.append({
                "audit_id": r["audit_id"],
                "created_at": created_at,
                "score": r["score"]
            })
        
        return {"domain": domain, "audits": history}


@app.get("/v1/leaderboard")
async def get_leaderboard(limit: int = 20):
    """
    Get top-scoring domains (public leaderboard).
    """
    driver = get_neo4j_driver()
    
    with driver.session() as session:
        result = session.run("""
            MATCH (d:Domain)
            WHERE d.current_score > 0
            RETURN d.name as domain, 
                   d.current_score as score,
                   d.last_audited as last_audited
            ORDER BY d.current_score DESC
            LIMIT $limit
        """, limit=limit)
        
        leaderboard = []
        for i, r in enumerate(result):
            last_audited = r["last_audited"]
            if hasattr(last_audited, 'to_native'):
                last_audited = last_audited.to_native().isoformat()
            
            leaderboard.append({
                "rank": i + 1,
                "domain": r["domain"],
                "score": r["score"],
                "last_audited": last_audited
            })
        
        return {"leaderboard": leaderboard}


# Stripe publishable key endpoint (for frontend)
@app.get("/v1/config")
async def get_config():
    """Get public configuration for frontend."""
    return {
        "stripe_publishable_key": settings.STRIPE_PUBLISHABLE_KEY,
        "google_client_id": settings.GOOGLE_CLIENT_ID
    }
