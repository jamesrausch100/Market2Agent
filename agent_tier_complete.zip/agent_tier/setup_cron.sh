#!/bin/bash
# Market2Agent - Cron Setup for Weekly Audits
# Run this script on Droplet 2 to set up scheduled jobs

# Add cron jobs
(crontab -l 2>/dev/null; echo "# Market2Agent Weekly Audits") | crontab -
(crontab -l 2>/dev/null; echo "0 0 * * 0 cd /opt/market2agent && /opt/market2agent/venv/bin/python -m app.scheduler weekly_audits >> /var/log/m2a-weekly.log 2>&1") | crontab -
(crontab -l 2>/dev/null; echo "0 1 * * 0 cd /opt/market2agent && /opt/market2agent/venv/bin/python -m app.scheduler process_alerts >> /var/log/m2a-alerts.log 2>&1") | crontab -

echo "Cron jobs installed:"
crontab -l

echo ""
echo "Schedule:"
echo "  - Weekly audits: Sunday at midnight UTC"
echo "  - Process alerts: Sunday at 1am UTC"
echo ""
echo "Logs:"
echo "  - /var/log/m2a-weekly.log"
echo "  - /var/log/m2a-alerts.log"
