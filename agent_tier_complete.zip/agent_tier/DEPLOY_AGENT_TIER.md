# Market2Agent Agent Tier - Deployment Guide

## What's New

This update adds:
1. **Google OAuth** - Users sign in with Google
2. **Stripe Subscriptions** - $20/month Agent Tier
3. **User Dashboard** - Track domains, view audits
4. **Scheduled Audits** - Weekly automated audits for subscribers
5. **Email Alerts** - Notifications when scores change

---

## Deployment Steps

### 1. Update Droplet 2 (API Server)

```bash
ssh root@<DROPLET2_IP>
cd /opt/market2agent

# Backup current code
cp -r app app.backup

# Copy new files (from this package)
# - app/config.py
# - app/auth.py
# - app/subscriptions.py
# - app/dashboard.py
# - app/scheduler.py
# - app/main.py (updated)

# Install new dependencies
source venv/bin/activate
pip install PyJWT authlib stripe

# Update .env with your secrets
nano .env
```

### 2. Configure .env

Copy these to `/opt/market2agent/.env`:

```env
# Database
NEO4J_URI=bolt://10.120.0.5:7687
NEO4J_USER=neo4j
NEO4J_PASSWORD=M2A_graph_2024_secure
REDIS_URL=redis://localhost:6379

# Stripe
STRIPE_SECRET_KEY=sk_test_51SvpDEPYWofQndIQkvWvJ1FqggmEUbcc9MZvaWNzWnz9nYgD3MJ1i2k5EBpCn9McL8kOfsKMQbGkZAvUac21Qj6r00TvciXKBw
STRIPE_PUBLISHABLE_KEY=pk_test_51SvpDEPYWofQndIQxFbXvcs1MaPE4CkHQ50XsXcS4Dg5VKPBymUFrXjMcAMrmKdpWDCakDlh1BHOElgqORVy0KDH00aFDeqoYw
STRIPE_PRICE_ID=price_1SvpOPPYWofQndIQfBTTzyoL
STRIPE_WEBHOOK_SECRET=whsec_REPLACE_AFTER_WEBHOOK_SETUP

# Google OAuth
GOOGLE_CLIENT_ID=238810496032-qijbmdhk8v5fca43sm4ncuop4nkvv51m.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=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

# Email
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=hello@market2agent.ai
SMTP_PASSWORD=YOUR_GMAIL_APP_PASSWORD

# App
SECRET_KEY=GENERATE_RANDOM_64_CHAR_STRING
APP_URL=https://market2agent.ai
API_URL=https://api.market2agent.ai
ENVIRONMENT=production
```

Generate SECRET_KEY:
```bash
python3 -c "import secrets; print(secrets.token_hex(32))"
```

### 3. Set Up Stripe Webhook

1. Go to Stripe Dashboard → Developers → Webhooks
2. Add endpoint: `https://api.market2agent.ai/v1/webhook/stripe`
3. Select events:
   - `checkout.session.completed`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.payment_failed`
4. Copy the webhook signing secret to `.env` as `STRIPE_WEBHOOK_SECRET`

### 4. Update Neo4j Schema

On Droplet 3 (or via Droplet 2):

```bash
cypher-shell -u neo4j -p M2A_graph_2024_secure << 'EOF'
// User constraints
CREATE CONSTRAINT user_id_unique IF NOT EXISTS
FOR (u:User) REQUIRE u.id IS UNIQUE;

CREATE CONSTRAINT user_google_id_unique IF NOT EXISTS
FOR (u:User) REQUIRE u.google_id IS UNIQUE;

CREATE CONSTRAINT user_email_unique IF NOT EXISTS
FOR (u:User) REQUIRE u.email IS UNIQUE;

// Index for subscription queries
CREATE INDEX user_subscription IF NOT EXISTS
FOR (u:User) ON (u.subscription_status);
EOF
```

### 5. Restart API

```bash
systemctl restart m2a-api
systemctl restart m2a-worker
```

### 6. Update Droplet 1 (Website)

Copy new frontend files:
- `/login.html`
- `/dashboard.html`
- `/settings.html`

```bash
ssh root@<DROPLET1_IP>
cd /var/www/market2agent

# Copy the new HTML files from this package
```

### 7. Set Up Cron for Weekly Audits

On Droplet 2:

```bash
chmod +x /opt/market2agent/setup_cron.sh
./setup_cron.sh
```

---

## Testing

### Test Google OAuth
1. Go to https://market2agent.ai/login.html
2. Click "Continue with Google"
3. Should redirect to dashboard after login

### Test Stripe Subscription
1. Login as a user
2. Click "Upgrade to Agent Tier"
3. Use test card: `4242 4242 4242 4242`
4. Should redirect back with active subscription

### Test Webhook
```bash
stripe listen --forward-to https://api.market2agent.ai/v1/webhook/stripe
```

---

## Gmail App Password

To send emails via Gmail:

1. Go to Google Account → Security
2. Enable 2-Factor Authentication (if not already)
3. Go to App passwords
4. Create new app password for "Mail"
5. Use this 16-character password in SMTP_PASSWORD

---

## File Structure

```
/opt/market2agent/
├── .env                    # Secrets (never commit!)
├── app/
│   ├── __init__.py
│   ├── config.py           # NEW - settings loader
│   ├── main.py             # UPDATED - includes new routes
│   ├── db.py
│   ├── auth.py             # NEW - Google OAuth
│   ├── subscriptions.py    # NEW - Stripe billing
│   ├── dashboard.py        # NEW - user domains API
│   ├── scheduler.py        # NEW - weekly jobs
│   ├── worker.py
│   ├── crawlers/
│   └── analyzers/
└── venv/

/var/www/market2agent/
├── index.html
├── about.html
├── services.html
├── blog.html
├── contact.html
├── audit.html
├── login.html              # NEW
├── dashboard.html          # NEW
├── settings.html           # NEW
├── css/
├── js/
└── images/
```

---

## Monitoring

Check logs:
```bash
journalctl -u m2a-api -f
journalctl -u m2a-worker -f
tail -f /var/log/m2a-weekly.log
```

---

## Going Live

When ready to accept real payments:

1. Switch Stripe keys from `sk_test_` to `sk_live_`
2. Update `STRIPE_PRICE_ID` to live price
3. Update webhook endpoint to use live signing secret
4. Test with a real card (refund yourself after)
