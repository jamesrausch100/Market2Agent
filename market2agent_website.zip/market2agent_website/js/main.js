/* ============================================
   Market2Agent - Main JavaScript
   ============================================ */

document.addEventListener('DOMContentLoaded', function() {
    // Mobile Navigation
    initMobileNav();
    
    // Header Scroll Effect
    initHeaderScroll();
    
    // Animate Score on Hero
    initHeroScoreAnimation();
    
    // Form Handlers
    initForms();
});

/* ----- Mobile Navigation ----- */
function initMobileNav() {
    const navToggle = document.getElementById('nav-toggle');
    const navClose = document.getElementById('nav-close');
    const navMenu = document.getElementById('nav-menu');
    
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            navMenu.classList.add('active');
            document.body.style.overflow = 'hidden';
        });
    }
    
    if (navClose && navMenu) {
        navClose.addEventListener('click', () => {
            navMenu.classList.remove('active');
            document.body.style.overflow = '';
        });
    }
    
    // Close on link click
    const navLinks = document.querySelectorAll('.nav__link');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (navMenu) {
                navMenu.classList.remove('active');
                document.body.style.overflow = '';
            }
        });
    });
    
    // Close on outside click
    document.addEventListener('click', (e) => {
        if (navMenu && navMenu.classList.contains('active')) {
            if (!navMenu.contains(e.target) && !navToggle.contains(e.target)) {
                navMenu.classList.remove('active');
                document.body.style.overflow = '';
            }
        }
    });
}

/* ----- Header Scroll Effect ----- */
function initHeaderScroll() {
    const header = document.getElementById('header');
    
    if (header) {
        let lastScroll = 0;
        
        window.addEventListener('scroll', () => {
            const currentScroll = window.pageYOffset;
            
            if (currentScroll > 100) {
                header.style.boxShadow = '0 4px 6px -1px rgb(0 0 0 / 0.1)';
            } else {
                header.style.boxShadow = 'none';
            }
            
            lastScroll = currentScroll;
        });
    }
}

/* ----- Hero Score Animation ----- */
function initHeroScoreAnimation() {
    const scoreElement = document.getElementById('hero-score');
    
    if (scoreElement) {
        const targetScore = 82;
        let currentScore = 0;
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateScore();
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });
        
        observer.observe(scoreElement);
        
        function animateScore() {
            const duration = 1500;
            const startTime = performance.now();
            
            function update(currentTime) {
                const elapsed = currentTime - startTime;
                const progress = Math.min(elapsed / duration, 1);
                
                // Easing function
                const easeOut = 1 - Math.pow(1 - progress, 3);
                currentScore = Math.round(easeOut * targetScore);
                
                scoreElement.textContent = currentScore;
                
                if (progress < 1) {
                    requestAnimationFrame(update);
                }
            }
            
            requestAnimationFrame(update);
        }
    }
}

/* ----- Form Handlers ----- */
function initForms() {
    // Contact Form
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(contactForm);
            const data = Object.fromEntries(formData);
            
            // In production, send to your API
            console.log('Contact form submitted:', data);
            
            // Show success message
            alert('Thanks for reaching out! We\'ll get back to you within 1 business day.');
            contactForm.reset();
        });
    }
    
    // Newsletter Form
    const newsletterForm = document.querySelector('.newsletter__form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const email = newsletterForm.querySelector('input[type="email"]').value;
            
            // In production, send to your email service
            console.log('Newsletter signup:', email);
            
            alert('Thanks for subscribing! Check your inbox for a confirmation.');
            newsletterForm.reset();
        });
    }
}

/* ----- CTA Audit Start ----- */
function startAudit() {
    const domain = document.getElementById('cta-domain');
    if (domain && domain.value.trim()) {
        // Redirect to audit page with domain
        window.location.href = `/audit.html?domain=${encodeURIComponent(domain.value.trim())}`;
    } else {
        window.location.href = '/audit.html';
    }
}

/* ----- Utility Functions ----- */
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Check for domain param on audit page
if (window.location.pathname.includes('audit')) {
    const params = new URLSearchParams(window.location.search);
    const domain = params.get('domain');
    if (domain) {
        const input = document.getElementById('domain-input');
        if (input) {
            input.value = domain;
            // Auto-run audit after short delay
            setTimeout(() => {
                if (typeof runAudit === 'function') {
                    runAudit();
                }
            }, 500);
        }
    }
}
