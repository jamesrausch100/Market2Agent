"""
Market2Agent - Async Worker
Handles background audit processing using arq (async Redis queue).
"""
import json
from arq import create_pool
from arq.connections import RedisSettings
import structlog

from app.db import create_or_get_domain, create_audit, complete_audit, store_entities
from app.crawlers.structured_data import crawl_domain
from app.crawlers.entity_presence import check_entity_presence
from app.analyzers.scoring import calculate_geo_score, generate_summary

logger = structlog.get_logger()

# Redis settings (localhost on Droplet 2)
REDIS_SETTINGS = RedisSettings(
    host='localhost',
    port=6379
)


async def enqueue_audit(audit_id: str, domain: str):
    """
    Enqueue an audit job for background processing.
    """
    redis = await create_pool(REDIS_SETTINGS)
    await redis.enqueue_job('run_audit', audit_id, domain)
    logger.info("audit_enqueued", audit_id=audit_id, domain=domain)


async def run_audit(ctx: dict, audit_id: str, domain: str):
    """
    Main audit worker function.
    Runs all crawlers and analyzers, stores results in Neo4j.
    """
    logger.info("audit_started", audit_id=audit_id, domain=domain)
    
    try:
        # 1. Create/get domain and audit records
        create_or_get_domain(domain)
        create_audit(audit_id, domain)
        
        # 2. Crawl for structured data
        logger.info("crawling_structured_data", domain=domain)
        crawl_result = await crawl_domain(domain)
        
        # Extract organization name for entity search
        org_name = None
        for entity in crawl_result.get("all_entities", []):
            if entity.get("@type") in ["Organization", "Corporation", "LocalBusiness"]:
                org_name = entity.get("name")
                break
        
        # 3. Check entity presence
        logger.info("checking_entity_presence", domain=domain, org_name=org_name)
        presence_result = await check_entity_presence(domain, org_name)
        
        # 4. Calculate scores
        logger.info("calculating_scores", audit_id=audit_id)
        
        # Prepare structured data for scoring
        homepage_data = crawl_result.get("structured_data", {})
        homepage_data["json_ld"] = crawl_result.get("all_entities", [])
        homepage_data["has_organization"] = any(
            e.get("@type") in ["Organization", "Corporation", "LocalBusiness"] 
            for e in crawl_result.get("all_entities", [])
        )
        homepage_data["has_website"] = any(
            e.get("@type") == "WebSite" 
            for e in crawl_result.get("all_entities", [])
        )
        
        score_result = calculate_geo_score(
            structured_data=homepage_data,
            entity_presence=presence_result
        )
        
        # 5. Build complete result
        result = {
            "audit_id": audit_id,
            "domain": domain,
            "scores": score_result["scores"],
            "max_scores": score_result["max_scores"],
            "grade": score_result["grade"],
            "summary": generate_summary(score_result),
            "findings": score_result["findings"],
            "recommendations": score_result["recommendations"],
            "entities": [
                {
                    "type": e.get("@type"),
                    "name": e.get("name"),
                    "source": e.get("_source"),
                    "page": e.get("_page")
                }
                for e in crawl_result.get("all_entities", [])
            ],
            "entity_presence": {
                "wikidata": presence_result.get("wikidata"),
                "wikipedia": presence_result.get("wikipedia")
            },
            "pages_crawled": len(crawl_result.get("pages_crawled", [])),
            "crawl_details": crawl_result.get("pages_crawled", [])
        }
        
        # 6. Store results
        complete_audit(
            audit_id=audit_id,
            score=score_result["overall_score"],
            raw_data=json.dumps(result)
        )
        
        # 7. Store entities in graph
        store_entities(audit_id, domain, crawl_result.get("all_entities", []))
        
        logger.info("audit_complete", 
            audit_id=audit_id, 
            domain=domain, 
            score=score_result["overall_score"],
            grade=score_result["grade"]
        )
        
        return result
        
    except Exception as e:
        logger.error("audit_failed", audit_id=audit_id, domain=domain, error=str(e))
        
        # Store failure
        error_result = {
            "error": str(e),
            "scores": {},
            "findings": [],
            "recommendations": [],
            "entities": []
        }
        complete_audit(
            audit_id=audit_id,
            score=0,
            raw_data=json.dumps(error_result)
        )
        
        raise


# --------------------------------------------------------------
# Worker Settings
# --------------------------------------------------------------

class WorkerSettings:
    """arq worker settings"""
    
    redis_settings = REDIS_SETTINGS
    
    functions = [run_audit]
    
    # Job settings
    max_jobs = 10
    job_timeout = 300  # 5 minutes max per audit
    
    # Health check
    health_check_interval = 30
    
    # Retry settings
    max_tries = 3
    retry_delay = 10


# --------------------------------------------------------------
# CLI for testing
# --------------------------------------------------------------

if __name__ == "__main__":
    import asyncio
    import sys
    
    async def test_audit():
        domain = sys.argv[1] if len(sys.argv) > 1 else "example.com"
        audit_id = f"test-{domain}"
        
        print(f"Running test audit for {domain}...")
        result = await run_audit({}, audit_id, domain)
        
        print("\n" + "="*60)
        print(f"AUDIT COMPLETE: {domain}")
        print("="*60)
        print(f"Score: {result['scores']}")
        print(f"Grade: {result['grade']}")
        print(f"Summary: {result['summary']}")
        print(f"\nEntities found: {len(result['entities'])}")
        print(f"Recommendations: {len(result['recommendations'])}")
        
        for rec in result['recommendations'][:3]:
            print(f"  - [{rec['priority']}] {rec['message']}")
    
    asyncio.run(test_audit())
