"""
Market2Agent - GEO Scoring Algorithm
Calculates Generative Engine Optimization score from audit data.
"""
from typing import Optional
import structlog

logger = structlog.get_logger()


# --------------------------------------------------------------
# Score Weights (total = 100)
# --------------------------------------------------------------

WEIGHTS = {
    "structured_data": 35,      # JSON-LD, Schema.org quality
    "entity_presence": 30,      # Wikidata, Wikipedia presence
    "content_clarity": 20,      # Clear identity, description
    "technical_signals": 15,    # DNS, SSL, headers
}


def calculate_geo_score(
    structured_data: dict,
    entity_presence: dict,
    content_analysis: Optional[dict] = None
) -> dict:
    """
    Calculate the overall GEO score from audit components.
    
    Returns:
        {
            "overall_score": float (0-100),
            "scores": {
                "structured_data": float,
                "entity_presence": float,
                "content_clarity": float,
                "technical_signals": float
            },
            "grade": str (A-F),
            "findings": [...],
            "recommendations": [...]
        }
    """
    scores = {}
    findings = []
    recommendations = []
    
    # --------------------------------------------------------------
    # 1. Structured Data Score (35 points max)
    # --------------------------------------------------------------
    sd_score = 0
    sd_max = WEIGHTS["structured_data"]
    
    # Has JSON-LD (most important)
    if structured_data.get("json_ld"):
        sd_score += 15
        findings.append({
            "type": "positive",
            "category": "structured_data",
            "message": f"Found {len(structured_data['json_ld'])} JSON-LD entities"
        })
    else:
        findings.append({
            "type": "negative",
            "category": "structured_data", 
            "message": "No JSON-LD structured data found"
        })
        recommendations.append({
            "priority": "high",
            "category": "structured_data",
            "message": "Add JSON-LD structured data to your homepage. Start with Organization schema.",
            "impact": "+15 points potential"
        })
    
    # Has Organization schema
    if structured_data.get("has_organization"):
        sd_score += 10
        findings.append({
            "type": "positive",
            "category": "structured_data",
            "message": "Organization schema detected"
        })
    else:
        findings.append({
            "type": "negative",
            "category": "structured_data",
            "message": "No Organization schema found"
        })
        recommendations.append({
            "priority": "high",
            "category": "structured_data",
            "message": "Add Organization schema with name, url, logo, and description properties.",
            "impact": "+10 points potential"
        })
    
    # Has WebSite schema
    if structured_data.get("has_website"):
        sd_score += 5
    
    # Validation errors reduce score
    errors = structured_data.get("validation_errors", [])
    error_count = len([e for e in errors if e.get("severity") == "error"])
    warning_count = len([e for e in errors if e.get("severity") == "warning"])
    
    sd_score -= (error_count * 3)
    sd_score -= (warning_count * 1)
    
    if error_count > 0:
        findings.append({
            "type": "negative",
            "category": "structured_data",
            "message": f"{error_count} validation errors in structured data"
        })
    
    # Has sameAs links (connects to other identities)
    for entity in structured_data.get("json_ld", []):
        if entity.get("sameAs"):
            sd_score += 5
            findings.append({
                "type": "positive",
                "category": "structured_data",
                "message": "sameAs links found (connects to social profiles/Wikipedia)"
            })
            break
    
    scores["structured_data"] = max(0, min(sd_score, sd_max))
    
    # --------------------------------------------------------------
    # 2. Entity Presence Score (30 points max)
    # --------------------------------------------------------------
    ep_score = 0
    ep_max = WEIGHTS["entity_presence"]
    
    # Wikidata presence
    if entity_presence.get("wikidata", {}).get("found"):
        ep_score += 15
        qid = entity_presence["wikidata"].get("qid", "")
        findings.append({
            "type": "positive",
            "category": "entity_presence",
            "message": f"Found on Wikidata ({qid})"
        })
        
        # Bonus for sameAs links in Wikidata
        if entity_presence["wikidata"].get("sameAs"):
            ep_score += 5
    else:
        findings.append({
            "type": "negative",
            "category": "entity_presence",
            "message": "Not found on Wikidata"
        })
        recommendations.append({
            "priority": "medium",
            "category": "entity_presence",
            "message": "Consider creating a Wikidata entry for your organization. This helps LLMs recognize your brand as a known entity.",
            "impact": "+15-20 points potential"
        })
    
    # Wikipedia presence
    if entity_presence.get("wikipedia", {}).get("found"):
        ep_score += 10
        findings.append({
            "type": "positive",
            "category": "entity_presence",
            "message": "Wikipedia article exists"
        })
    else:
        findings.append({
            "type": "info",
            "category": "entity_presence",
            "message": "No Wikipedia article found"
        })
        # Only recommend if company is notable enough
        recommendations.append({
            "priority": "low",
            "category": "entity_presence",
            "message": "If your organization meets Wikipedia's notability guidelines, consider creating an article. Not recommended for new/small companies.",
            "impact": "+10 points potential"
        })
    
    scores["entity_presence"] = max(0, min(ep_score, ep_max))
    
    # --------------------------------------------------------------
    # 3. Content Clarity Score (20 points max)
    # --------------------------------------------------------------
    cc_score = 0
    cc_max = WEIGHTS["content_clarity"]
    
    meta = structured_data.get("meta", {})
    
    # Has clear title
    if meta.get("title") and len(meta["title"]) > 10:
        cc_score += 5
    else:
        recommendations.append({
            "priority": "medium",
            "category": "content_clarity",
            "message": "Add a clear, descriptive page title."
        })
    
    # Has meta description
    if meta.get("description") and len(meta["description"]) > 50:
        cc_score += 5
        findings.append({
            "type": "positive",
            "category": "content_clarity",
            "message": "Meta description present"
        })
    else:
        findings.append({
            "type": "negative",
            "category": "content_clarity",
            "message": "Missing or short meta description"
        })
        recommendations.append({
            "priority": "high",
            "category": "content_clarity",
            "message": "Add a clear meta description (50-160 chars) that explains what your company does."
        })
    
    # Has canonical URL
    if meta.get("canonical"):
        cc_score += 3
    
    # Check for clear organization description in structured data
    for entity in structured_data.get("json_ld", []):
        if entity.get("@type") in ["Organization", "Corporation"]:
            if entity.get("description") and len(entity["description"]) > 30:
                cc_score += 7
                findings.append({
                    "type": "positive",
                    "category": "content_clarity",
                    "message": "Clear organization description in structured data"
                })
                break
    
    scores["content_clarity"] = max(0, min(cc_score, cc_max))
    
    # --------------------------------------------------------------
    # 4. Technical Signals Score (15 points max)
    # --------------------------------------------------------------
    ts_score = 0
    ts_max = WEIGHTS["technical_signals"]
    
    dns = entity_presence.get("dns_records", {})
    
    if dns.get("has_mx"):
        ts_score += 3
    if dns.get("has_spf"):
        ts_score += 3
    if dns.get("has_dmarc"):
        ts_score += 4
        findings.append({
            "type": "positive",
            "category": "technical",
            "message": "Email authentication (DMARC) configured"
        })
    
    # Robots.txt check would go here
    ts_score += 5  # Placeholder - assume basic technical setup
    
    scores["technical_signals"] = max(0, min(ts_score, ts_max))
    
    # --------------------------------------------------------------
    # Calculate Overall Score & Grade
    # --------------------------------------------------------------
    overall_score = sum(scores.values())
    
    # Determine grade
    if overall_score >= 90:
        grade = "A"
    elif overall_score >= 80:
        grade = "B"
    elif overall_score >= 70:
        grade = "C"
    elif overall_score >= 60:
        grade = "D"
    else:
        grade = "F"
    
    # Sort recommendations by priority
    priority_order = {"high": 0, "medium": 1, "low": 2}
    recommendations.sort(key=lambda x: priority_order.get(x.get("priority", "low"), 3))
    
    return {
        "overall_score": round(overall_score, 1),
        "scores": {k: round(v, 1) for k, v in scores.items()},
        "max_scores": WEIGHTS,
        "grade": grade,
        "findings": findings,
        "recommendations": recommendations
    }


def generate_summary(score_result: dict) -> str:
    """
    Generate a human-readable summary of the audit.
    """
    grade = score_result["grade"]
    overall = score_result["overall_score"]
    
    summaries = {
        "A": f"Excellent GEO readiness ({overall}/100). Your site is well-optimized for generative AI discovery.",
        "B": f"Good GEO readiness ({overall}/100). Minor improvements could boost your AI visibility.",
        "C": f"Moderate GEO readiness ({overall}/100). Several areas need attention for better AI discovery.",
        "D": f"Below average GEO readiness ({overall}/100). Significant improvements recommended.",
        "F": f"Poor GEO readiness ({overall}/100). Major optimizations required for AI visibility."
    }
    
    return summaries.get(grade, f"GEO Score: {overall}/100")
