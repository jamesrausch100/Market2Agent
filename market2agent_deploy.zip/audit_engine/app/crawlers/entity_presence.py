"""
Market2Agent - Entity Presence Checker
Checks if a brand/organization exists on authoritative knowledge bases.
"""
import httpx
from typing import Optional
import structlog
from urllib.parse import quote

logger = structlog.get_logger()


async def check_entity_presence(domain: str, organization_name: Optional[str] = None) -> dict:
    """
    Check for entity presence across authoritative sources.
    
    Checks:
    - Wikidata (structured knowledge graph)
    - Wikipedia (encyclopedic presence)
    - Google Knowledge Graph (via Search API if configured)
    - Crunchbase (if company)
    
    Returns:
        {
            "wikidata": {"found": bool, "qid": str, "label": str, "description": str},
            "wikipedia": {"found": bool, "url": str, "extract": str},
            "knowledge_panel_signals": {...},
            "overall_presence_score": float
        }
    """
    result = {
        "wikidata": {"found": False},
        "wikipedia": {"found": False},
        "dns_records": {},
        "overall_presence_score": 0.0,
        "checks_performed": []
    }
    
    # Determine search term
    search_term = organization_name or domain.replace(".com", "").replace(".io", "").replace("-", " ")
    
    # Check Wikidata
    wikidata_result = await check_wikidata(search_term)
    result["wikidata"] = wikidata_result
    result["checks_performed"].append("wikidata")
    
    # Check Wikipedia
    wikipedia_result = await check_wikipedia(search_term)
    result["wikipedia"] = wikipedia_result
    result["checks_performed"].append("wikipedia")
    
    # Calculate presence score
    score = 0.0
    
    if result["wikidata"]["found"]:
        score += 40  # Wikidata presence is significant
        # Bonus for having sameAs links
        if result["wikidata"].get("sameAs"):
            score += 10
    
    if result["wikipedia"]["found"]:
        score += 35  # Wikipedia article is significant
        # Bonus for longer articles
        if len(result["wikipedia"].get("extract", "")) > 500:
            score += 10
    
    # Check for domain-level signals
    dns_result = await check_dns_signals(domain)
    result["dns_records"] = dns_result
    result["checks_performed"].append("dns")
    
    if dns_result.get("has_mx"):
        score += 2  # Has email
    if dns_result.get("has_spf"):
        score += 1  # Has SPF (legitimacy signal)
    if dns_result.get("has_dmarc"):
        score += 2  # Has DMARC (legitimacy signal)
    
    result["overall_presence_score"] = min(score, 100)  # Cap at 100
    
    return result


async def check_wikidata(search_term: str) -> dict:
    """
    Search Wikidata for an entity matching the search term.
    """
    result = {"found": False}
    
    try:
        # Wikidata API search
        search_url = "https://www.wikidata.org/w/api.php"
        params = {
            "action": "wbsearchentities",
            "search": search_term,
            "language": "en",
            "format": "json",
            "type": "item",
            "limit": 5
        }
        
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(search_url, params=params)
            response.raise_for_status()
            data = response.json()
            
            if data.get("search"):
                # Take the first result (most relevant)
                entity = data["search"][0]
                qid = entity["id"]
                
                result = {
                    "found": True,
                    "qid": qid,
                    "label": entity.get("label", ""),
                    "description": entity.get("description", ""),
                    "url": f"https://www.wikidata.org/wiki/{qid}"
                }
                
                # Fetch additional details (sameAs links)
                details = await fetch_wikidata_entity(qid)
                if details:
                    result["sameAs"] = details.get("sameAs", [])
                    result["instance_of"] = details.get("instance_of", [])
                    
    except Exception as e:
        logger.error("wikidata_check_failed", error=str(e))
        result["error"] = str(e)
    
    return result


async def fetch_wikidata_entity(qid: str) -> Optional[dict]:
    """
    Fetch detailed info about a Wikidata entity.
    """
    try:
        url = f"https://www.wikidata.org/wiki/Special:EntityData/{qid}.json"
        
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(url)
            response.raise_for_status()
            data = response.json()
            
            entity = data.get("entities", {}).get(qid, {})
            claims = entity.get("claims", {})
            
            result = {
                "sameAs": [],
                "instance_of": []
            }
            
            # P31 = instance of
            if "P31" in claims:
                for claim in claims["P31"]:
                    value = claim.get("mainsnak", {}).get("datavalue", {}).get("value", {})
                    if isinstance(value, dict) and "id" in value:
                        result["instance_of"].append(value["id"])
            
            # P856 = official website
            if "P856" in claims:
                for claim in claims["P856"]:
                    value = claim.get("mainsnak", {}).get("datavalue", {}).get("value")
                    if value:
                        result["sameAs"].append(value)
            
            # P2002 = Twitter username
            if "P2002" in claims:
                for claim in claims["P2002"]:
                    value = claim.get("mainsnak", {}).get("datavalue", {}).get("value")
                    if value:
                        result["sameAs"].append(f"https://twitter.com/{value}")
            
            # P2013 = Facebook ID
            if "P2013" in claims:
                for claim in claims["P2013"]:
                    value = claim.get("mainsnak", {}).get("datavalue", {}).get("value")
                    if value:
                        result["sameAs"].append(f"https://facebook.com/{value}")
            
            return result
            
    except Exception as e:
        logger.error("wikidata_fetch_failed", qid=qid, error=str(e))
        return None


async def check_wikipedia(search_term: str) -> dict:
    """
    Check if an entity has a Wikipedia article.
    """
    result = {"found": False}
    
    try:
        # Wikipedia API search
        search_url = "https://en.wikipedia.org/w/api.php"
        params = {
            "action": "query",
            "list": "search",
            "srsearch": search_term,
            "format": "json",
            "srlimit": 3
        }
        
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(search_url, params=params)
            response.raise_for_status()
            data = response.json()
            
            search_results = data.get("query", {}).get("search", [])
            
            if search_results:
                # Get the first result
                page_title = search_results[0]["title"]
                
                # Fetch extract
                extract_params = {
                    "action": "query",
                    "titles": page_title,
                    "prop": "extracts",
                    "exintro": True,
                    "explaintext": True,
                    "format": "json"
                }
                
                extract_response = await client.get(search_url, params=extract_params)
                extract_data = extract_response.json()
                
                pages = extract_data.get("query", {}).get("pages", {})
                page = list(pages.values())[0] if pages else {}
                
                result = {
                    "found": True,
                    "title": page_title,
                    "url": f"https://en.wikipedia.org/wiki/{quote(page_title.replace(' ', '_'))}",
                    "extract": page.get("extract", "")[:500]  # First 500 chars
                }
                
    except Exception as e:
        logger.error("wikipedia_check_failed", error=str(e))
        result["error"] = str(e)
    
    return result


async def check_dns_signals(domain: str) -> dict:
    """
    Check DNS records for legitimacy signals.
    Note: This is a simplified check. In production, use dnspython.
    """
    # For now, return placeholder
    # In production, implement actual DNS lookups
    return {
        "has_mx": True,  # Would check MX records
        "has_spf": True,  # Would check TXT for SPF
        "has_dmarc": True,  # Would check _dmarc.domain TXT
        "note": "DNS checks require dnspython in production"
    }
