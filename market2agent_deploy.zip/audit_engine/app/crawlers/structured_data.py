"""
Market2Agent - Structured Data Extraction
Extracts JSON-LD, Microdata, RDFa, OpenGraph, and Meta tags from websites.
"""
import httpx
from bs4 import BeautifulSoup
import extruct
import json
from typing import Optional
from urllib.parse import urljoin
import structlog

logger = structlog.get_logger()

# Standard headers to appear as a legitimate crawler
HEADERS = {
    "User-Agent": "Market2Agent/1.0 (GEO Audit Bot; +https://market2agent.com/bot)",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
}


async def fetch_page(url: str, timeout: float = 30.0) -> Optional[str]:
    """
    Fetch a page's HTML content.
    Returns None if the page cannot be fetched.
    """
    async with httpx.AsyncClient(follow_redirects=True, timeout=timeout) as client:
        try:
            response = await client.get(url, headers=HEADERS)
            response.raise_for_status()
            return response.text
        except httpx.HTTPError as e:
            logger.error("fetch_failed", url=url, error=str(e))
            return None


def extract_structured_data(html: str, base_url: str) -> dict:
    """
    Extract all structured data from HTML.
    
    Returns:
        {
            "json_ld": [...],
            "microdata": [...],
            "rdfa": [...],
            "opengraph": {...},
            "meta": {...},
            "schema_types": [...],  # List of Schema.org types found
            "has_organization": bool,
            "has_website": bool,
            "validation_errors": [...]
        }
    """
    result = {
        "json_ld": [],
        "microdata": [],
        "rdfa": [],
        "opengraph": {},
        "meta": {},
        "schema_types": [],
        "has_organization": False,
        "has_website": False,
        "validation_errors": []
    }
    
    try:
        # Use extruct to extract all structured data formats
        data = extruct.extract(
            html,
            base_url=base_url,
            syntaxes=['json-ld', 'microdata', 'rdfa', 'opengraph'],
            uniform=True
        )
        
        result["json_ld"] = data.get("json-ld", [])
        result["microdata"] = data.get("microdata", [])
        result["rdfa"] = data.get("rdfa", [])
        result["opengraph"] = data.get("opengraph", [])
        
        # Collect all schema types found
        all_entities = result["json_ld"] + result["microdata"] + result["rdfa"]
        schema_types = set()
        
        for entity in all_entities:
            if isinstance(entity, dict):
                entity_type = entity.get("@type")
                if entity_type:
                    if isinstance(entity_type, list):
                        schema_types.update(entity_type)
                    else:
                        schema_types.add(entity_type)
                    
                    # Check for key entity types
                    if entity_type in ["Organization", "Corporation", "LocalBusiness"] or \
                       (isinstance(entity_type, list) and any(t in entity_type for t in ["Organization", "Corporation", "LocalBusiness"])):
                        result["has_organization"] = True
                    
                    if entity_type == "WebSite" or (isinstance(entity_type, list) and "WebSite" in entity_type):
                        result["has_website"] = True
        
        result["schema_types"] = list(schema_types)
        
        # Extract basic meta tags
        soup = BeautifulSoup(html, 'lxml')
        result["meta"] = extract_meta_tags(soup)
        
        # Validate the structured data
        result["validation_errors"] = validate_structured_data(result)
        
    except Exception as e:
        logger.error("extraction_failed", error=str(e))
        result["validation_errors"].append(f"Extraction failed: {str(e)}")
    
    return result


def extract_meta_tags(soup: BeautifulSoup) -> dict:
    """
    Extract standard meta tags.
    """
    meta = {
        "title": None,
        "description": None,
        "canonical": None,
        "robots": None,
    }
    
    # Title
    title_tag = soup.find("title")
    if title_tag:
        meta["title"] = title_tag.get_text(strip=True)
    
    # Meta description
    desc_tag = soup.find("meta", attrs={"name": "description"})
    if desc_tag:
        meta["description"] = desc_tag.get("content", "")
    
    # Canonical URL
    canonical = soup.find("link", attrs={"rel": "canonical"})
    if canonical:
        meta["canonical"] = canonical.get("href", "")
    
    # Robots
    robots = soup.find("meta", attrs={"name": "robots"})
    if robots:
        meta["robots"] = robots.get("content", "")
    
    return meta


def validate_structured_data(data: dict) -> list:
    """
    Validate structured data against common issues.
    Returns a list of validation errors/warnings.
    """
    errors = []
    
    # Check for JSON-LD presence
    if not data["json_ld"]:
        errors.append({
            "severity": "warning",
            "code": "NO_JSON_LD",
            "message": "No JSON-LD structured data found. This is the preferred format for LLM consumption."
        })
    
    # Check for Organization
    if not data["has_organization"]:
        errors.append({
            "severity": "warning", 
            "code": "NO_ORGANIZATION",
            "message": "No Organization/Corporation schema found. LLMs may have difficulty identifying brand entity."
        })
    
    # Check for WebSite schema
    if not data["has_website"]:
        errors.append({
            "severity": "info",
            "code": "NO_WEBSITE_SCHEMA",
            "message": "No WebSite schema found. Consider adding for search action support."
        })
    
    # Validate JSON-LD entities
    for i, entity in enumerate(data["json_ld"]):
        if isinstance(entity, dict):
            # Check for @context
            if "@context" not in entity:
                errors.append({
                    "severity": "error",
                    "code": "MISSING_CONTEXT",
                    "message": f"JSON-LD entity {i} missing @context"
                })
            
            # Check for @type
            if "@type" not in entity:
                errors.append({
                    "severity": "error",
                    "code": "MISSING_TYPE",
                    "message": f"JSON-LD entity {i} missing @type"
                })
            
            # Check Organization has required properties
            entity_type = entity.get("@type", "")
            if entity_type in ["Organization", "Corporation", "LocalBusiness"]:
                required = ["name"]
                recommended = ["url", "logo", "description", "sameAs"]
                
                for prop in required:
                    if prop not in entity:
                        errors.append({
                            "severity": "error",
                            "code": f"ORG_MISSING_{prop.upper()}",
                            "message": f"Organization missing required property: {prop}"
                        })
                
                for prop in recommended:
                    if prop not in entity:
                        errors.append({
                            "severity": "info",
                            "code": f"ORG_MISSING_{prop.upper()}",
                            "message": f"Organization missing recommended property: {prop}"
                        })
    
    return errors


async def crawl_domain(domain: str) -> dict:
    """
    Crawl a domain's homepage and key pages for structured data.
    
    Returns comprehensive structured data analysis.
    """
    base_url = f"https://{domain}"
    
    result = {
        "domain": domain,
        "pages_crawled": [],
        "total_entities": 0,
        "structured_data": {},
        "errors": []
    }
    
    # Pages to check
    pages_to_crawl = [
        "/",
        "/about",
        "/about-us", 
        "/contact",
    ]
    
    all_entities = []
    all_schema_types = set()
    
    for path in pages_to_crawl:
        url = urljoin(base_url, path)
        html = await fetch_page(url)
        
        if html:
            page_data = extract_structured_data(html, url)
            result["pages_crawled"].append({
                "url": url,
                "status": "success",
                "schema_types": page_data["schema_types"],
                "entity_count": len(page_data["json_ld"]) + len(page_data["microdata"]),
                "validation_errors": page_data["validation_errors"]
            })
            
            # Collect entities
            for entity in page_data["json_ld"]:
                entity["_source"] = "json-ld"
                entity["_page"] = url
                all_entities.append(entity)
            
            for entity in page_data["microdata"]:
                entity["_source"] = "microdata"
                entity["_page"] = url
                all_entities.append(entity)
            
            all_schema_types.update(page_data["schema_types"])
            
            # Store homepage data specially
            if path == "/":
                result["structured_data"] = page_data
        else:
            result["pages_crawled"].append({
                "url": url,
                "status": "failed",
                "schema_types": [],
                "entity_count": 0
            })
    
    result["total_entities"] = len(all_entities)
    result["all_entities"] = all_entities
    result["all_schema_types"] = list(all_schema_types)
    
    return result
