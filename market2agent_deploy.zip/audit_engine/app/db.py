"""
Market2Agent - Neo4j Database Connection
"""
from neo4j import GraphDatabase
from functools import lru_cache
import os

NEO4J_URI = os.getenv("NEO4J_URI", "bolt://10.120.0.3:7687")
NEO4J_USER = os.getenv("NEO4J_USER", "neo4j")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "M2A_graph_2024_secure")


@lru_cache(maxsize=1)
def get_neo4j_driver():
    """
    Returns a singleton Neo4j driver instance.
    Connection is cached for reuse across requests.
    """
    driver = GraphDatabase.driver(
        NEO4J_URI,
        auth=(NEO4J_USER, NEO4J_PASSWORD),
        max_connection_lifetime=3600,
        max_connection_pool_size=50,
    )
    # Verify connectivity
    driver.verify_connectivity()
    return driver


def close_driver():
    """Close the driver when shutting down."""
    driver = get_neo4j_driver()
    driver.close()


# --------------------------------------------------------------
# Database Operations
# --------------------------------------------------------------

def create_or_get_domain(domain: str) -> dict:
    """
    Get existing domain or create new one.
    Returns the domain node properties.
    """
    driver = get_neo4j_driver()
    
    with driver.session() as session:
        result = session.run("""
            MERGE (d:Domain {name: $domain})
            ON CREATE SET 
                d.first_seen = datetime(),
                d.current_score = 0,
                d.tier = 'free'
            RETURN d
        """, domain=domain.lower())
        
        record = result.single()
        return dict(record["d"]) if record else None


def create_audit(audit_id: str, domain: str) -> dict:
    """
    Create a new audit record linked to a domain.
    """
    driver = get_neo4j_driver()
    
    with driver.session() as session:
        result = session.run("""
            MATCH (d:Domain {name: $domain})
            CREATE (a:Audit {
                audit_id: $audit_id,
                created_at: datetime(),
                status: 'processing',
                overall_score: 0
            })
            CREATE (d)-[:HAS_AUDIT]->(a)
            RETURN a
        """, domain=domain.lower(), audit_id=audit_id)
        
        record = result.single()
        return dict(record["a"]) if record else None


def complete_audit(audit_id: str, score: float, raw_data: str):
    """
    Mark an audit as complete and store results.
    Also update the domain's current score.
    """
    driver = get_neo4j_driver()
    
    with driver.session() as session:
        session.run("""
            MATCH (d:Domain)-[:HAS_AUDIT]->(a:Audit {audit_id: $audit_id})
            SET a.status = 'complete',
                a.overall_score = $score,
                a.raw_data = $raw_data,
                a.completed_at = datetime(),
                d.current_score = $score,
                d.last_audited = datetime()
        """, audit_id=audit_id, score=score, raw_data=raw_data)


def store_entities(audit_id: str, domain: str, entities: list):
    """
    Store extracted entities and link them to the domain.
    """
    driver = get_neo4j_driver()
    
    with driver.session() as session:
        for entity in entities:
            session.run("""
                MATCH (d:Domain {name: $domain})
                MERGE (e:Entity {
                    schema_type: $schema_type,
                    name: $name,
                    domain: $domain
                })
                ON CREATE SET
                    e.description = $description,
                    e.url = $url,
                    e.extracted_from = $source,
                    e.first_seen = datetime()
                ON MATCH SET
                    e.last_seen = datetime()
                MERGE (d)-[:HAS_ENTITY]->(e)
            """, 
                domain=domain.lower(),
                schema_type=entity.get("@type", "Thing"),
                name=entity.get("name", "Unknown"),
                description=entity.get("description", ""),
                url=entity.get("url", ""),
                source=entity.get("_source", "json-ld")
            )


def link_wikidata_entity(domain: str, entity_name: str, qid: str, label: str, description: str):
    """
    Link a domain's entity to a Wikidata entity (SAME_AS relationship).
    """
    driver = get_neo4j_driver()
    
    with driver.session() as session:
        session.run("""
            MATCH (d:Domain {name: $domain})-[:HAS_ENTITY]->(e:Entity {name: $entity_name})
            MERGE (w:WikidataEntity {qid: $qid})
            ON CREATE SET
                w.label = $label,
                w.description = $description,
                w.last_checked = datetime()
            MERGE (e)-[:SAME_AS]->(w)
        """,
            domain=domain.lower(),
            entity_name=entity_name,
            qid=qid,
            label=label,
            description=description
        )
