#!/bin/bash
# ==============================================================
# Market2Agent - Droplet 3 Neo4j Setup
# Run as root on a fresh Ubuntu 22.04/24.04 droplet
# ==============================================================

set -e

echo ">>> Updating system..."
apt-get update && apt-get upgrade -y

echo ">>> Installing Java 17 (required for Neo4j)..."
apt-get install -y openjdk-17-jre-headless

echo ">>> Adding Neo4j repository..."
curl -fsSL https://debian.neo4j.com/neotechnology.gpg.key | gpg --dearmor -o /usr/share/keyrings/neo4j-archive-keyring.gpg
echo "deb [signed-by=/usr/share/keyrings/neo4j-archive-keyring.gpg] https://debian.neo4j.com stable latest" | tee /etc/apt/sources.list.d/neo4j.list

echo ">>> Installing Neo4j Community Edition..."
apt-get update
apt-get install -y neo4j

echo ">>> Configuring Neo4j for internal network access..."

# Backup original config
cp /etc/neo4j/neo4j.conf /etc/neo4j/neo4j.conf.backup

# Configure to listen on internal IP only (not public internet)
cat >> /etc/neo4j/neo4j.conf << 'EOF'

# ===== Market2Agent Custom Config =====
# Listen on internal VPC IP only
server.default_listen_address=10.120.0.3

# Bolt connector (what our API uses)
server.bolt.enabled=true
server.bolt.listen_address=10.120.0.3:7687

# HTTP connector (for Neo4j Browser - disable in prod, useful for setup)
server.http.enabled=true
server.http.listen_address=10.120.0.3:7474

# Disable HTTPS for internal traffic
server.https.enabled=false

# Memory settings (adjust based on droplet size)
server.memory.heap.initial_size=1g
server.memory.heap.max_size=2g
server.memory.pagecache.size=512m
EOF

echo ">>> Setting initial Neo4j password..."
neo4j-admin dbms set-initial-password M2A_graph_2024_secure

echo ">>> Starting Neo4j service..."
systemctl enable neo4j
systemctl start neo4j

echo ">>> Waiting for Neo4j to start..."
sleep 10

echo ">>> Verifying Neo4j is running..."
systemctl status neo4j --no-pager

echo ""
echo "=========================================="
echo " Neo4j installed successfully!"
echo "=========================================="
echo " Internal Bolt URL: bolt://10.120.0.3:7687"
echo " Username: neo4j"
echo " Password: M2A_graph_2024_secure"
echo ""
echo " Test from Droplet 2 with:"
echo " curl http://10.120.0.3:7474"
echo "=========================================="
