#!/bin/bash
# ==============================================================
# Market2Agent - Droplet 2 Audit Engine Setup
# Run as root on Ubuntu 22.04/24.04
# ==============================================================

set -e

echo ">>> Updating system..."
apt-get update && apt-get upgrade -y

echo ">>> Installing Python 3.11 and dependencies..."
apt-get install -y python3.11 python3.11-venv python3.11-dev python3-pip
apt-get install -y build-essential libxml2-dev libxslt1-dev
apt-get install -y redis-server  # For task queue
apt-get install -y nginx         # Reverse proxy

echo ">>> Creating application user..."
useradd -m -s /bin/bash m2a || true

echo ">>> Setting up application directory..."
mkdir -p /opt/market2agent
chown m2a:m2a /opt/market2agent

echo ">>> Creating Python virtual environment..."
sudo -u m2a python3.11 -m venv /opt/market2agent/venv

echo ">>> Installing Python packages..."
sudo -u m2a /opt/market2agent/venv/bin/pip install --upgrade pip
sudo -u m2a /opt/market2agent/venv/bin/pip install \
    fastapi[standard] \
    uvicorn[standard] \
    httpx \
    beautifulsoup4 \
    lxml \
    extruct \
    neo4j \
    redis \
    arq \
    pydantic \
    python-dotenv \
    structlog

echo ">>> Configuring Redis..."
systemctl enable redis-server
systemctl start redis-server

echo ">>> Creating systemd service for API..."
cat > /etc/systemd/system/m2a-api.service << 'EOF'
[Unit]
Description=Market2Agent Audit API
After=network.target

[Service]
Type=simple
User=m2a
WorkingDirectory=/opt/market2agent
Environment="PATH=/opt/market2agent/venv/bin"
ExecStart=/opt/market2agent/venv/bin/uvicorn app.main:app --host 10.120.0.4 --port 8000
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

echo ">>> Creating systemd service for worker..."
cat > /etc/systemd/system/m2a-worker.service << 'EOF'
[Unit]
Description=Market2Agent Audit Worker
After=network.target redis-server.service

[Service]
Type=simple
User=m2a
WorkingDirectory=/opt/market2agent
Environment="PATH=/opt/market2agent/venv/bin"
ExecStart=/opt/market2agent/venv/bin/arq app.worker.WorkerSettings
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

echo ">>> Setting up Nginx reverse proxy..."
cat > /etc/nginx/sites-available/m2a-api << 'EOF'
server {
    listen 80;
    server_name api.market2agent.com;

    location / {
        proxy_pass http://10.120.0.4:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF

ln -sf /etc/nginx/sites-available/m2a-api /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

echo ">>> Creating application directory structure..."
sudo -u m2a mkdir -p /opt/market2agent/app
sudo -u m2a mkdir -p /opt/market2agent/app/crawlers
sudo -u m2a mkdir -p /opt/market2agent/app/analyzers
sudo -u m2a mkdir -p /opt/market2agent/app/models

echo ""
echo "=========================================="
echo " Audit Engine environment ready!"
echo "=========================================="
echo " Next: Copy the application code to"
echo " /opt/market2agent/app/"
echo ""
echo " Then run:"
echo " systemctl daemon-reload"
echo " systemctl enable m2a-api m2a-worker"
echo " systemctl start m2a-api m2a-worker"
echo "=========================================="
